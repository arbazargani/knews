@include ('_temps/public/header_view')
@include ('_temps/public/top_nav_bar_view')
@include ('_temps/public/site_header_view')
@include ('_temps/public/menu_view')

@include('_temps/index/index_content_view')

@include ('_temps/public/footer_view')
@include ('_temps/public/ending')