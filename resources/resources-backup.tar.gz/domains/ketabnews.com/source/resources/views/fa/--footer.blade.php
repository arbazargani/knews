<footer class="mainFooterWrap">
    <div class="container-fluid noBackgroundInPrint">
        <div class="row">
            <div id="ctl00_cphFooter_Container523" class=" container-fluid ">
                <div id="ctl00_cphFooter_cphFooter_row_523_0" class="row row523">
                    <div id="ctl00_cphFooter_cphFooterTop_Container528" class="footerTop col-md-10 col-md-offset-1 col-xs-12">
                        <div id="ctl00_cphFooter_cphFooterTop_cphFooterTop_row_528_0" class="row row528">
                            <div id="ctl00_cphFooter_cphFooterTop_pnl00cphFooterTop_129" class="col-cms col-md-12 ">
                                <div class="inner ">


                                    <nav class="footerNav noPrint">

                                        <div id="ctl00_cphFooter_cphFooterTop_Sampa_Web_View_GeneralUI_FooterLinksContol00cphFooterTop_129_pnlFooterLink" class="linearFooter">

                                            <ul>
                                                <li><a href="{{ route('archive') }}">آرشیو</a></li>
                                                <li><a href="{{ route('contactus') }}">ارتباط با ما</a></li>
                                                <li><a href="{{ route('aboutus') }}">درباره ما</a></li>
                                                <li><a target="_blank" href="{{ url('rss') }}">RSS</a></li>
<li style="
    padding: 0;
    margin: 0;
    float: left;
    border-right: 3px solid red;
    padding-right: 10px;
">
    <a style="
    padding: 0;
    margin: 0;
" id="" title="کتاب نیوز" class="mainLogoLink" href="#">
        <img id="" class="img-responsive mainLogoImage" src="{{ url('images/4_orig.png') }}" alt="کتاب نیوز" style="border-width:0px;"/>
    </a>
</li>
                                            </ul>

                                        </div>

                                    </nav>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="ctl00_cphFooter_cphFooterBottom_cphFooterBottom_parent_row_529" class="placeHolderWrapper" style="background:url({{ url('images/14_orig.png') }});">
                        <div id="ctl00_cphFooter_cphFooterBottom_Container529" class="footerBottom col-xs-12">
                            <div id="ctl00_cphFooter_cphFooterBottom_cphFooterBottom_row_529_0" class="row row529">
                                <div id="ctl00_cphFooter_cphFooterBottom_pnl00cphFooterBottom_130" class="col-cms col-md-12 ">
                                    <div class="inner ">



                                        <span id="" class="h5 mainLogoDescription"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row radcomCopyrightAndLogo">
            <div class="container">
                <div class="col-md-10 col-md-offset-1 col-md-np col-lg-np col-xs-12">
                    <div class="pull-right">

                        <div class="generalCopyright">
                            کلیه حقوق این وب سایت متعلق به کتاب نیوز می باشد.
                        </div>

                    </div>
                    <div class="pull-left noPrint">

                        <div class="generalPoweredBy">
                            <a id="ctl00_PoweredByLink_hplPowerByWebdesign" title="طراحی سایت" rel="nofollow" href="#" target="_blank">طراحی سایت</a>


                            <span id="ctl00_PoweredByLink_lblPowerByTextBy">توسط</span>
                            <a id="ctl00_PoweredByLink_hplPowerByRadcom" title="توکا" rel="nofollow" href="http://toca.ir" target="_blank">توکا</a>
                            <a id="ctl00_PoweredByLink_hplPowerByLogo" rel="nofollow" href="#" target="_blank">
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>