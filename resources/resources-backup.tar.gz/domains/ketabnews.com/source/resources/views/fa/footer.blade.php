<footer class="mainFooterWrap">
    <div class="container-fluid noBackgroundInPrint">
        <div class="row">
            <div id="" class=" container-fluid ">
                <div id="" class="row row523">
                    <div id="" class="footerTop col-md-10 col-md-offset-1 col-xs-12">
                        <div id="" class="row row528">
                            <div id="" class="col-cms col-md-12 ">
                                <div class="inner ">

                                    <style>
                                        .mainFooterWrap .mainLogoImage{
                                            padding: 0;
                                        }
                                        .footer-link a{
                                            color: #000;
                                        }
                                        .footer-link {
                                            top: 5px;
                                        }
                                        .footer-link > .rss{
                                            padding-right: 20px;
                                            padding-left: 23px;
                                        }
                                        .footer-link > .archive , .contactus{
                                            padding-left: 15px;
                                        }
                                        .aboutus{
                                            padding-left: 92px;
                                            padding-right: 10px;
                                        }
                                        .mainLogoImage{
                                            border-width:0px;    margin-right: 0;
                                        }
                                        @media(min-width:992px){
                                            .divmainlogo{
                                                margin-right: 8px;
                                            }
                                        }
                                        @media(max-width:992px){
                                            .mainLogoImage{
                                                width: 200px;
                                                margin: 0 auto;
                                                padding-top: 10px;
                                            }
                                            .copyright{
                                                text-align: center;
                                            }
                                        }
                                        @media(max-width:768px){
                                            .mainLogoImage{
                                                width: 200px;
                                                margin: 0 auto;
                                                padding-top: 10px;
                                            }
                                            .copyright{
                                                text-align: center;
                                            }

                                        }
                                    </style>
                                    <nav class="footerNav noPrint">

                                        <div id="" class="linearFooter">

                                            <div class="row">
                                                <!--<div class="col-md-4"></div>-->
                                                <div class="col-md-7 col-md-offset-1 footer-link">
													<a style="padding-right: 45px" href="{{ url('tags/150/رمان ایرانی') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >رمان ایرانی</span></a>
													<a style="" href="{{ url('tags/102/خاطره، سفرنامه و روایت') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >خاطره، سفرنامه و روایت</span></a>
													<a style="" href="{{ url('tags/316/جامعه شناسی') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >جامعه شناسی</span></a>
													<a style="" href="{{ url('tags/148/هنر') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >هنر</span></a>
													<a style="" href="{{ url('tags/123/زندگی نامه') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >زندگی نامه</span></a>
													<a style="" href="{{ url('tags/125/مرجع') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >مرجع</span></a>
													<a style="" href="{{ url('tags/81/کتابشناسی') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >کتابشناسی</span></a>
													<a style="" href="{{ url('tags/140/نقد') }}" class="first"> <span style="color: #186975;padding-left: 2px; border-left:2px solid #006478" >نقد</span></a>
												
												
                                                    <a style="color: #186975 ; padding-right: 2px;padding-left: 2px;border-left: 2px solid #006478" class="archive"  href="{{ route('archive') }}">بایگانی</a>
                                                    {{--<a class="contactus"  href="{{ route('contactus') }}">ارتباط با ما</a>--}}
                                                    <a style="color: #186975 ;padding-left: 2px;padding-right: 2px; border-left: 2px solid #006478" class="rss"  rel="alternate" type="application/atom+xml" target="_blank" href="{{ url('rss') }}">پیگیری</a>
                                                    <a style="color: #186975;padding-right: 2px;padding-left: 2px" class="aboutus"  href="{{ route('aboutus') }}">شناسنامه</a>
                                                </div>

                                                <div class="col-md-2" style="border-right: 2px solid black;margin-right: 20px;;/*margin-right: -83px;*/">
                                                    <a style=" padding: 0;  margin: 0; " id="" title="کتاب نیوز"
                                                       class="mainLogoLink" href="#">
                                                        <img id="" class="img-responsive mainLogoImage"
                                                             src="{{ url('images/4_orig.png') }}" alt="کتاب نیوز"
                                                             style=""/>
                                                    </a>
                                                </div>
                                                <div class="col-md-1"></div>
                                            </div>

                                        </div>

                                    </nav>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="" class="placeHolderWrapper" style="background:url({{ url('images/14_orig.png') }});">
                        <div id="" class="footerBottom col-xs-12">
                            <div id="" class="row row529">
                                <div id="" class="col-cms col-md-12 ">
                                    <div class="inner ">

                                        <div class="row">
                                            <div class="col-md-4"></div>
                                            <div class="col-md-3 col-md-offset-2 copyright" style="padding-right: 15px;color: #fff;font-size: 10px" >
											کلیه حقوق محفوظ است و بازنشر مطالب با ذکر 
                                                <a style="color: #fff;" href="{{ url('/') }}">کتاب نیوز</a>
                                                و درج لینک، بلامانع .
                                            </div>

                                            <div class="col-md-2" style="border-right: 2px solid black;margin-right: -18px;">
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>




                                        <span id="" class="h5 mainLogoDescription"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<script type="text/javascript">
	$(document).ready(function () {
		$('#a-btn-search').click(function(){
			$('#fsearch').submit();
		});		
	});
</script>

